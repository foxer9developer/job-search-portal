## Spring Job Portal

Job portal for job seekers and companies, developed in Spring and Hibernate.

### Installing and Running the application

Just run the Application.java.
Type http://localhost:8080/findjobs in your browser to open the application.
