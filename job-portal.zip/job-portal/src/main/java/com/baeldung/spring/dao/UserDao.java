/**
 * 
 */
package com.baeldung.spring.dao;

/**
 * @author Tushar
 *
 */
public interface UserDao {

}
